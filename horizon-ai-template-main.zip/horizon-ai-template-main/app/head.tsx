import React from 'react';

export default function RootHead() {
  return (
    <>
      <title>Horizon AI Template PRO</title>
    </>
  );
}
